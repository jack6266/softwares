License code: 
	1. add -javaagent:/path/to/ja-netfilter.jar to your vmoptions
	2. use key on page https://jetbra.in/5d84466e31722979266057664941a71893322460

Or

License server:
	1. add -javaagent:/path/to/ja-netfilter.jar to your vmoptions
	2. use license server url: https://jetbra.in

Enjoy it~