#error JRuby does not support native extensions
