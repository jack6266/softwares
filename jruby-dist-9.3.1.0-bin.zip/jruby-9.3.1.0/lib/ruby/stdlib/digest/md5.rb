# Load built-in digest/md5 library
JRuby::Util.load_ext("org.jruby.ext.digest.MD5")
