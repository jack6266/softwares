# Load built-in digest/rmd160 library
JRuby::Util.load_ext("org.jruby.ext.digest.RMD160")
