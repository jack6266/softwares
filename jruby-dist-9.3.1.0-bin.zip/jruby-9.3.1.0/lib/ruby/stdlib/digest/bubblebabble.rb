# Load built-in digest/bubblebabble library
JRuby::Util.load_ext("org.jruby.ext.digest.BubbleBabble")
