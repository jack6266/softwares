module Jars
  VERSION = '0.4.1'.freeze
  JRUBY_PLUGINS_VERSION = '1.1.3'.freeze
  DEPENDENCY_PLUGIN_VERSION = '2.8'.freeze
end
